import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:opay_eg/widgets/financecards.dart';
class Finance extends StatefulWidget {
  const Finance({super.key});

  @override
  State<Finance> createState() => _FinanceState();
}
Future<void> refresh(){
  return Future.delayed(Duration(seconds: 2));
}
class _FinanceState extends State<Finance> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Finance",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
        actions: [Text("from BlueRidge Microfinance Bank",style: TextStyle(fontSize: 12),)],
        actionsPadding: EdgeInsets.only(right: 16),
      ),
      body: RefreshIndicator(
        color: Colors.greenAccent,
        onRefresh: refresh,
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: SingleChildScrollView(
            child: Column(
              children: [
              Container(
                width: double.maxFinite,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 197, 225, 248),
                  borderRadius: BorderRadius.circular(12)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2), decoration: BoxDecoration(color: const Color.fromARGB(255, 4, 82, 145),borderRadius: BorderRadius.only(topLeft: Radius.circular(16),bottomLeft: Radius.circular(16),topRight: Radius.circular(16))), child: Text("Safebox",style: TextStyle(fontSize: 10,color: Colors.white, fontWeight: FontWeight.w500),),),
                   Container(
                    padding: EdgeInsets.only(left: 12),
                     child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                       children: [
                         Text("Save daily, weekly, or monthly",style: TextStyle(fontWeight: FontWeight.bold, color: Color.fromARGB(255, 4, 82, 145)),),
                         Text("Earn interest every month",style: TextStyle(fontWeight: FontWeight.bold, color: Color.fromARGB(255, 4, 82, 145)),),
                         Text("4 free withdrawal days yearly",style: TextStyle(color: Color.fromARGB(255, 4, 82, 145)),),
                         SizedBox(height: 8,),
                         Row(
                           children: [
                             Container(
                              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Color.fromARGB(255, 4, 82, 145)),
                              child: Center(
                                child: Text("Start Saving",style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),),
                              ),
                             ),
                           ],
                         ),
                         SizedBox(height: 8,),
                       ],
                     ),
                   ),
                   Container(
                    padding: EdgeInsets.symmetric(horizontal: 2,vertical: 3),
                    decoration: BoxDecoration(color: Color.fromARGB(255, 4, 82, 145), borderRadius: BorderRadius.circular(12)),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                                
                      children: [
                        Text("Licensed by the CBN ",style: TextStyle(color: Colors.white,fontSize: 8)),
                        SvgPicture.asset("asset/cbn.svg", width: 12,height: 12,),
                        Text("| Insured by the ",style: TextStyle(color: Colors.white,fontSize: 8)),
                        Text("|NDIC ",style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white,fontSize: 8),),
                        Text("| Powered by BlueBridge MFB",overflow: TextOverflow.ellipsis,style: TextStyle(color: Colors.white,fontSize: 8))
                      ],
                                       ),
                    ),
                   )
                  ],
                ),
              ),
              SizedBox(height: 16,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(width: 24,),
                Text("Savings",style: TextStyle(fontWeight: FontWeight.bold),),
                Text("Loan",style: TextStyle(fontWeight: FontWeight.bold),),
                Icon(Icons.settings_outlined)
              ],),
              SizedBox(height: 16,),
              Row(
                children: [
                  Text("Total Balance"), SizedBox(width: 4,), Icon(Icons.remove_red_eye_outlined),
                  Spacer(),
                  Text("Total Interest")
                ],
              ),
              Row(
                children: [
                  Text.rich(
                    TextSpan(children: [
                      TextSpan(text: "₦ ", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      TextSpan(text: "25,590", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
                      TextSpan(text: ".89", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))
                    ])
                  ),
                  Spacer(),
                  Text.rich(
                    TextSpan(children: [
                      TextSpan(text: "₦ ", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color.fromARGB(255, 54, 153, 57))),
                      TextSpan(text: "5,490", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: Color.fromARGB(255, 54, 153, 57))),
                      TextSpan(text: ".70", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color.fromARGB(255, 54, 153, 57)))
                    ])
                  ),
                ],
              ),
              SizedBox(height: 12,),
              Container(
                height:  MediaQuery.of(context).size.height,
                child: GridView(
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisSpacing: 6,
                    crossAxisSpacing: 6,
                    crossAxisCount: 2
                    ),
                  children: [
                    Financecards(iconName: "asset/loan.svg", iconColor: Colors.deepPurpleAccent, color: const Color.fromARGB(255, 247, 236, 250), title: "OWealth", textBody: "Your daily returns. You can withdraw at any time",money: "₦25,590.89",),
                    Financecards(iconName: "asset/creditcard.svg", iconColor: Color.fromARGB(255, 54, 153, 57), color: const Color.fromARGB(255, 234, 255, 251), title: "Wallet", textBody: "Your account baance is.",money: "₦5,490.70",),
                    Financecards(iconName: "asset/circledcircle.svg", iconColor: const Color.fromARGB(255, 20, 106, 177), color: Color.fromARGB(255, 238, 238, 238), title: "Targets", textBody: "Save daily, weekly, or monthly towards your goal."),
                    Financecards(iconName: "asset/wallet.svg", iconColor: Colors.redAccent, color: Color.fromARGB(255, 238, 238, 238), title: "SafeBox", textBody: "Your daily, weekly or monthly automatic savings."),
                    Financecards(iconName: "asset/oldtv.svg", iconColor: Color.fromARGB(255, 54, 153, 57), color: Color.fromARGB(255, 238, 238, 238), title: "Fixed", textBody: "Min: ₦1000 \nTenor: 7-1000 days"),
                    Financecards(iconName: "asset/moneybag.svg", iconColor: Colors.amber, color: Color.fromARGB(255, 238, 238, 238), title: "Spend & Save", textBody: "Your percentage savings every time you spend or transfer."),
                    Financecards(iconName: "asset/chart.svg", iconColor: Colors.deepPurple, color: Color.fromARGB(255, 238, 238, 238), title: "Savings Report", textBody: "Check out your savings journey so far"),
                  ],
                ),
              )
            ],
            ),
          ),
          ),
      ),
    );
  }
}