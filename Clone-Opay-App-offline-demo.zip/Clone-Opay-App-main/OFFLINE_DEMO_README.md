# Offline transfer simulator changes

This fork adds a separate offline-only demo flow. It does not connect to a bank, send funds, verify accounts, or change a real wallet balance. Every simulated receipt is labelled `DEMO — NOT A REAL PAYMENT`.

## Changes
- Added `lib/pages/demo_transfer.dart` with demo recipient/account/bank/amount fields.
- Uses `shared_preferences` to persist a local list of simulated demo transactions.
- Adds a visible “Offline transfer simulator” entry card to the existing bank transfer screen.
- Adds the `/demo-transfer` route.

## Build
From the project root in a Flutter environment:

```sh
flutter pub get
flutter analyze
flutter build apk --debug
```

The APK has not been compiled or tested in this environment. Use fictional recipient details only. Local storage is not secure storage and is not suitable for real financial data.
