import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Offline-only transfer simulator. It never contacts a bank or payment API.
class DemoTransferPage extends StatefulWidget {
  const DemoTransferPage({super.key});

  @override
  State<DemoTransferPage> createState() => _DemoTransferPageState();
}

class _DemoTransferPageState extends State<DemoTransferPage> {
  final _formKey = GlobalKey<FormState>();
  final _recipient = TextEditingController();
  final _account = TextEditingController();
  final _bank = TextEditingController();
  final _amount = TextEditingController();
  List<Map<String, dynamic>> _transactions = [];
  static const _storageKey = 'offline_demo_transactions_v1';

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  @override
  void dispose() {
    _recipient.dispose();
    _account.dispose();
    _bank.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _loadTransactions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      if (mounted) setState(() => _transactions = decoded
          .map((item) => Map<String, dynamic>.from(item as Map))
          .toList());
    } catch (_) {
      // Ignore malformed local demo data rather than crashing the app.
    }
  }

  Future<void> _saveDemoTransfer() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = double.parse(_amount.text.trim());
    final now = DateTime.now();
    final tx = <String, dynamic>{
      'recipient': _recipient.text.trim(),
      'account': _account.text.trim(),
      'bank': _bank.text.trim(),
      'amount': amount,
      'date': now.toIso8601String(),
      'reference': 'DEMO-${now.millisecondsSinceEpoch}',
      'status': 'SIMULATED — NOT SENT',
    };
    final updated = [tx, ..._transactions];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(updated));
    if (!mounted) return;
    setState(() => _transactions = updated);
    _showReceipt(tx);
  }

  void _showReceipt(Map<String, dynamic> tx) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Column(children: [
          Icon(Icons.info_outline, color: Colors.deepOrange, size: 38),
          SizedBox(height: 8),
          Text('DEMO RECEIPT', textAlign: TextAlign.center),
          SizedBox(height: 4),
          Text('NOT A REAL PAYMENT', textAlign: TextAlign.center,
              style: TextStyle(color: Colors.deepOrange, fontSize: 13, fontWeight: FontWeight.bold)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Text('₦${(tx['amount'] as num).toStringAsFixed(2)}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          const Divider(height: 24),
          _receiptRow('Recipient', '${tx['recipient']}'),
          _receiptRow('Account', '${tx['account']}'),
          _receiptRow('Bank', '${tx['bank']}'),
          _receiptRow('Date', DateTime.parse('${tx['date']}').toLocal().toString().split('.').first),
          _receiptRow('Reference', '${tx['reference']}'),
          const SizedBox(height: 12),
          const Text('This is a locally saved simulation. No funds were transferred.',
              style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Close'))],
      ),
    );
  }

  Widget _receiptRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 82, child: Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12))),
      Expanded(child: Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
    ]),
  );

  Future<void> _clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
    if (mounted) setState(() => _transactions = []);
  }

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF087A45);
    return Scaffold(
      appBar: AppBar(title: const Text('Offline Transfer Demo'), backgroundColor: Colors.white, foregroundColor: Colors.black),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.orange.shade50, border: Border.all(color: Colors.deepOrange), borderRadius: BorderRadius.circular(10)),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.warning_amber_rounded, color: Colors.deepOrange), SizedBox(width: 8),
            Expanded(child: Text('DEMO MODE ONLY — works offline. No bank connection, no real transfer, and no real balance changes.', style: TextStyle(fontWeight: FontWeight.w600))),
          ]),
        ),
        const SizedBox(height: 16),
        Form(key: _formKey, child: Column(children: [
          _field(_recipient, 'Fictional recipient name', required: true),
          _field(_account, 'Demo account number (10 digits)', required: true, digits: true, maxLength: 10),
          _field(_bank, 'Fictional bank name', required: true),
          _field(_amount, 'Demo amount (₦)', required: true, digits: true),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: green, foregroundColor: Colors.white),
            onPressed: _saveDemoTransfer,
            icon: const Icon(Icons.receipt_long), label: const Text('Save demo & show demo receipt'),
          )),
        ])),
        const SizedBox(height: 26),
        Row(children: [const Expanded(child: Text('Saved demo history', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          if (_transactions.isNotEmpty) TextButton(onPressed: _clearHistory, child: const Text('Clear'))]),
        if (_transactions.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: Text('No demo transactions saved yet.')),
        ..._transactions.map((tx) => Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text('${tx['recipient']} • ₦${(tx['amount'] as num).toStringAsFixed(2)}'),
          subtitle: Text('DEMO — NOT SENT\n${tx['bank']} • ${tx['reference']}'),
          isThreeLine: true,
          onTap: () => _showReceipt(tx),
        ))),
      ]),
    );
  }

  Widget _field(TextEditingController controller, String label, {bool required = false, bool digits = false, int? maxLength}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: controller,
      keyboardType: digits ? TextInputType.number : TextInputType.text,
      maxLength: maxLength,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), counterText: ''),
      validator: (value) {
        final v = value?.trim() ?? '';
        if (required && v.isEmpty) return 'Required for this demo';
        if (digits && v.isNotEmpty && int.tryParse(v) == null) return 'Enter digits only';
        if (controller == _account && v.isNotEmpty && v.length != 10) return 'Enter 10 digits';
        if (controller == _amount && v.isNotEmpty && (double.tryParse(v) == null || double.parse(v) <= 0)) return 'Enter an amount greater than zero';
        return null;
      },
    ),
  );
}
