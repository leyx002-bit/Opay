import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class Financecards extends StatelessWidget {
  final String iconName;
  final Color color;
  final String title;
  final String textBody;
  final String? money;
  final Color iconColor;
  const Financecards({
    super.key,
    required this.iconName,
    required this.color,
    required this.title,
    required this.textBody,
    required this.iconColor,
    this.money,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: color,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SvgPicture.asset(iconName, width: 20, height: 20,color: iconColor,),
              SizedBox(width: 4),
              Expanded(
                child: Container(
                  child: Text(
                    title,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
          Text(
            textBody,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          Spacer(),
          Text(money ?? "", style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
