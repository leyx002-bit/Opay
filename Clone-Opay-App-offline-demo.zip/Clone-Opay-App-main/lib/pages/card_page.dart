import 'package:dashbord/layouts/bottom_nav.dart';
import 'package:flutter/material.dart';
import 'package:dashbord/constant/colors.dart';

import '../component/physical_card.dart';
import '../component/virtual_card_page.dart';

class CardPage extends StatefulWidget {
  const CardPage({super.key});

  @override
  State<CardPage> createState() => _CardPageState();
}

class _CardPageState extends State<CardPage> {
  final PageController _pageController = PageController();
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: Container(
          padding: const EdgeInsets.only(top: 14, left: 5, right: 4),
          color: Colors.white,
          child: SafeArea(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  "Card",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 24,
                    color: Colors.black,
                  ),
                ),
                Text('Q&A', style: TextStyle(
                 color: AppColors.primary
                ),)

              ],
            ),
          ),
        ),
      ),

      // ✅ Fixed Section Below
      body: Column(
        children: [
          /// ✅ Tab bar + underline
          SizedBox(
            height: 50,
            child: LayoutBuilder(
              builder: (context, constraints) {
                double tabWidth = constraints.maxWidth / 2;
                double underlineWidth = 40;


                return Stack(
                  children: [
                    Row(
                      children: [
                        tabButton("Virtual Card", 0),
                        tabButton("Physic Card", 1),
                      ],
                    ),

                    AnimatedBuilder(
                      animation: _pageController,
                      builder: (context, child) {
                        double page = _pageController.hasClients
                            ? _pageController.page ?? currentIndex.toDouble()
                            : currentIndex.toDouble();

                        return Positioned(
                          bottom: 0,
                          left: (page * tabWidth) + (tabWidth / 2) - (underlineWidth / 2),
                          child: Container(
                            width: 40,
                            height: 3,
                            color: AppColors.primary,
                          ),
                        );
                      },
                    ),
                  ],
                );
              },
            ),
          ),
          SizedBox(height: 12,),
          /// ✅ PageView takes whole space
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (index) => setState(() => currentIndex = index),
              children: [
                VirtualCardPage(),
                PhysicalCardPage()
              ],
            ),
          ),
        ],
      ),

      bottomNavigationBar: const CustomBottomNav(currentIndex: 3),
    );
  }

  Widget tabButton(String text, int index) {
    return Expanded(
      child: GestureDetector(
        onTap: () => _pageController.animateToPage(
          index,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 16,
              fontWeight: currentIndex == index ? FontWeight.bold : FontWeight.normal,
              color: currentIndex == index ? Colors.black : Colors.grey,
            ),
          ),
        ),
      ),
    );
  }
}
