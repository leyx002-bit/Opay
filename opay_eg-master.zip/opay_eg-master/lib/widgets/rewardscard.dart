import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Rewardscard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String moretitle;
  final String percent;
  final String cashback;
  const Rewardscard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.moretitle,
    required this.percent,
    required this.cashback,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: const Color.fromARGB(255, 238, 236, 236),
          ),
          child: Center(
            child: SvgPicture.asset(
              "asset/internetconnection.svg",
              width: 24,
              height: 24,
            ),
          ),
        ),
        SizedBox(width: 4),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 72,
                  child: Text(
                    title,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                SvgPicture.asset("asset/coin.svg", width: 24, height: 24),
                Text(
                  moretitle,
                  style: TextStyle(color: Color.fromARGB(255, 54, 153, 57)),
                ),
              ],
            ),
            Container(
              width: 200,
              child: Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: subtitle,
                      style: TextStyle(
                        overflow: TextOverflow.ellipsis,
                        fontSize: 11,
                        color: Colors.grey,
                      ),
                    ),
                    TextSpan(
                      text: percent,
                      style: TextStyle(
                        overflow: TextOverflow.ellipsis,
                        fontSize: 11,
                        color: const Color.fromARGB(255, 54, 153, 57),
                      ),
                    ),
                    TextSpan(
                      text: cashback,
                      style: TextStyle(
                        overflow: TextOverflow.ellipsis,
                        fontSize: 11,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(width: 4),
        Container(
          padding: EdgeInsets.only(left: 16, right: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color.fromARGB(255, 113, 243, 226),
                const Color.fromARGB(255, 88, 204, 140),
              ],
            ),
            borderRadius: BorderRadius.circular(30),
          ),
          child: Text(
            "Go",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
