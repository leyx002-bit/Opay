import 'package:flutter/material.dart';

class Cardlist extends StatelessWidget {
  final Widget svg;
  final String title;
  final Widget subtitle;
  const Cardlist({super.key,
  required this.svg,
  required this.title,
  required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(99),
          color: const Color.fromARGB(255, 210, 240, 225),
        ),
        child: Center(
          child: svg,
        ),
      ),
        SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container( child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14),)),
                
              ],
            ),
            subtitle,
          ],
        ),
      ],
    ); 
    
  }
}
