import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 240, 237, 237),
      appBar: AppBar(
      backgroundColor: Color.fromARGB(255, 216, 255, 248),
      leadingWidth: 36,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: SvgPicture.asset("asset/circledcircle.svg"),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        Text("Hi, CHUKWUMA", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),),
        Container(
          padding: EdgeInsets.symmetric(vertical: 1),
          width: 54,
          decoration: BoxDecoration(color: const Color.fromARGB(255, 255, 238, 211), borderRadius: BorderRadius.circular(30)),child: Row(children: [
          SvgPicture.asset("asset/coin.svg",height: 14, width: 14,), SizedBox(width: 4,),
          Text("Tier 3", style: TextStyle(color: Colors.orange, fontSize: 8),)
        ],),)
      ],),
      actions: [Badge(smallSize: 8, backgroundColor: Colors.red, child: Icon(Icons.settings_outlined))],
      actionsPadding: EdgeInsets.only(right: 16),
    ),
    body: SingleChildScrollView(
      child: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(color: Color.fromARGB(255, 216, 255, 248)),
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Container(
                    color: Color.fromARGB(255, 240, 237, 237),
                    ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Text("Total Balance",style: TextStyle(fontSize: 12),),SizedBox(width: 4,), Icon(Icons.remove_red_eye,size: 16,)
                ],),
                SizedBox(height: 8,),
                Text.rich(
                  TextSpan(children: [
                    TextSpan(text: "₦ ", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    TextSpan(text: "25,590", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28)),
                    TextSpan(text: ".89", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14))
                  ])
                ),
                SizedBox(height: 8,),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Text.rich(
                    TextSpan(children: [
                      TextSpan(text: "& Cashback ", style: TextStyle(fontSize: 11)),
                      TextSpan(text: "₦4.00",style: TextStyle(fontSize: 11, color: const Color.fromARGB(255, 67, 136, 69)))
                      ])
                      ),
                      ),
                      SizedBox(height: 12,),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(color: Color.fromARGB(255, 120, 211, 161),borderRadius: BorderRadius.circular(12)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                          Expanded(
                            flex: 3,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.warning,color: Colors.orange,size: 16,),
                                SizedBox(width: 4,),
                                Flexible(
                                  child: Container(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                      Text("3 Safety Tips",style: TextStyle(color: Colors.white,fontSize: 15),),
                                      Text("Make your account more secure.",overflow: TextOverflow.ellipsis,style: TextStyle(color: Colors.white,fontSize: 12),),
                                    ],),
                                  ),
                                ),
                              ],
                            ),
                          ), 
                          SizedBox(width: 8,),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(16)),
                                  child: Text("View",style: TextStyle(color: Color.fromARGB(255, 120, 211, 161),fontSize: 14, fontWeight: FontWeight.bold),),
                                ),
                              ],
                            ),
                          ),
                          
                        ],),
                      ),
                      SizedBox(height: 8,),
                      Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),color: Colors.white),
                            child: Column(
                              children: [
                                ListTile(leading: SvgPicture.asset("asset/contactnotebook.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161)),title: Text("Transaction History"),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                                ListTile(leading: SvgPicture.asset("asset/globe.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161)),title: Text("Account Limits"),subtitle: Text("View your transaction limits",style: TextStyle(color: Colors.grey, fontSize: 11),),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                                ListTile(leading: SvgPicture.asset("asset/creditcard.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161)),title: Text("Bank Card/Account"),subtitle: Text("1 linked card/account",style: TextStyle(color: Colors.grey, fontSize: 11)),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                                ListTile(leading: SvgPicture.asset("asset/bank.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161)),title: Text("Transfer to Me"),subtitle: Text("Receive payment for your business",style: TextStyle(color: Colors.grey, fontSize: 11)),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                              ],
                            ),
                          ),
                          SizedBox(height: 8,),
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),color: Colors.white),
                            child: Column(children: [
                              ListTile(leading: SvgPicture.asset("asset/shieldcheck.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161),),title: Text("Security Center"),subtitle: Text("Protect your funds",style: TextStyle(color: Colors.grey, fontSize: 11)),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                              ListTile(leading: SvgPicture.asset("asset/user.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161),),title: Text("Customer Service Center"),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                              ListTile(leading: SvgPicture.asset("asset/handheart.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161),),title: Text("Invitation"),subtitle: Text("Invite friends and earn up to ₦4,600 Bonus",style: TextStyle(color: Colors.grey, fontSize: 11)),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                              ListTile(leading: SvgPicture.asset("asset/wallet.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161),),title: Text("OPay USSD"),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                              ListTile(leading: SvgPicture.asset("asset/personsquare.svg",height: 28,width: 28, color: Color.fromARGB(255, 120, 211, 161),),title: Text("Rate Us"),trailing: Icon(Icons.arrow_forward_ios,size: 16,),),
                            ],),
                          ),
              ],
            ),
          )
        ],
      ),
    ),
    );
  }
}