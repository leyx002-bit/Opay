import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:opay_eg/screens/cards.dart';
import 'package:opay_eg/screens/finance.dart';
import 'package:opay_eg/screens/home.dart';
import 'package:opay_eg/screens/profile.dart';
import 'package:opay_eg/screens/rewards.dart';

class Screens extends StatefulWidget {
  const Screens({super.key});

  @override
  State<Screens> createState() => _ScreensState();
}

class _ScreensState extends State<Screens> {
  
  List pages = [Home(), Rewards(), Finance(), Cards(), Profile()];

  int currentPage = 0;
  
  void updatePage(int page) {
    setState(() {
      currentPage = page;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(243, 255, 255, 255),
      body: pages[currentPage],
      bottomNavigationBar: BottomNavigationBar(
        selectedFontSize: 12,
        type: BottomNavigationBarType.fixed,
        currentIndex: currentPage,
        onTap: updatePage,
        showUnselectedLabels: true,
        selectedItemColor: Color.fromARGB(255, 4, 177, 93),
        unselectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              "asset/circledcircle.svg",
              width: 24,
              height: 24,
              color: Color.fromARGB(255, 141, 141, 141),
            ),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              "asset/diamond.svg",
              width: 24,
              height: 24,
              color: const Color.fromARGB(255, 141, 141, 141),
            ),
            label: "Rewards",
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              "asset/chart.svg",
              width: 24,
              height: 22,
              color: const Color.fromARGB(255, 141, 141, 141),
            ),
            label: "Finance",
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              "asset/creditcard.svg",
              width: 24,
              height: 24,
              color: const Color.fromARGB(255, 141, 141, 141),
            ),
            label: "Cards",
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              "asset/user.svg",
              width: 24,
              height: 24,
              color: const Color.fromARGB(255, 141, 141, 141),
            ),
            label: "Me",
          ),
        ],
      ),
    );
  }
}
