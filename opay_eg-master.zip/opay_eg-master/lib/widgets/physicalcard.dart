import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:opay_eg/widgets/physicalcardicons.dart';
class Physicalcard extends StatelessWidget {
  const Physicalcard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 12,right: 12, top: 16, bottom: 6),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 120, 211, 161),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SvgPicture.asset(
                          "asset/circledcircle.svg",
                          color: Colors.white,
                          width: 24,
                          height: 24,
                        ),
                        Text(
                          "Pay",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                        Spacer(),
                        Text("debit",style: TextStyle(color: Color.fromARGB(255, 12, 70, 118)),)
                      ],
                    ),
                    SizedBox(height: 100),
                    Row(
                      children: [
                        Text(
                          "Physical Card",
                          style: TextStyle(color: Colors.white),
                        ),
                        Spacer(),
                        SvgPicture.asset(
                          "asset/verve-seeklogo.svg",
                          height: 24,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 12,),
            Container(
              width: double.maxFinite,
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),color: const Color.fromARGB(255, 255, 224, 224)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                Text("Your card has been locked. \nUnlock your card to enjoy \nmore benefits.",style: TextStyle(fontSize: 13),),
                SizedBox(height: 8,),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 6,vertical: 2),
                  decoration: BoxDecoration(color: Colors.red,borderRadius: BorderRadius.circular(12)),
                  child: Text("Replace Card",style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600,fontSize: 14),),
                )
              ],),
            ),
            SizedBox(height: 12,),
            Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Physicalcardicons(
                        tittle: "Replace card",
                        iconName: Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                "asset/creditcard.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ),  
                      ),
                    
                      Physicalcardicons(
                        tittle: "Details",
                        iconName: Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                "asset/internetconnection.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ),  
                      ),
                    
                    Physicalcardicons(
                      tittle: "Card Settings",
                      iconName:Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                 "asset/tv.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ), 
                    ),
                  ],
                ),
                SizedBox(height: 4),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Physicalcardicons(
                      tittle: "Manage Dispute",
                      iconName: Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                "asset/wallet.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ),
                    ),
                     Physicalcardicons(
                      tittle: "Manage Online Merchant",
                      iconName: Badge(
                      backgroundColor: Colors.red,
                      label: Text(
                        "New",
                        style: TextStyle(fontSize: 6, color: Colors.white),
                      ),
                      child: Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                "asset/loan.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ),)
                    ),
                    Physicalcardicons(
                      tittle: "Transactions",
                      iconName:Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                "asset/internetconnection.svg",
                color: const Color.fromARGB(255, 4, 177, 93),
                width: 24,
                height: 24,
              ),
            ),
          ), 
                    ),
                  ],
                ),
              ],
            ),
                        )
          ],
        ),
      ),
    );
  }
}