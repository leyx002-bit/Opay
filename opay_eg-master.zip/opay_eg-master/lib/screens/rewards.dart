import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:opay_eg/widgets/brokenlines.dart';
import 'package:opay_eg/widgets/home_icons.dart';
import 'package:opay_eg/widgets/rewardscard.dart';

class Rewards extends StatefulWidget {
  const Rewards({super.key});

  @override
  State<Rewards> createState() => _RewardsState();
}

class _RewardsState extends State<Rewards> {
  @override
  Widget build(BuildContext context) {
    List<Color> vgrad = [const Color.fromARGB(255, 220, 247, 241), Colors.greenAccent];
    LinearGradient mgrad = LinearGradient(colors: vgrad);
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 240, 237, 237),
      appBar: AppBar(
        title: Text(
          "Rewards",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              border: Border.all(width: 2, color: Colors.black),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Icon(Icons.more_horiz_rounded),
          ),
        ],
        actionsPadding: EdgeInsets.fromLTRB(0, 0, 12, 0),
        backgroundColor: const Color.fromARGB(255, 216, 255, 248),
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 216, 255, 248),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(12),
                          bottomRight: Radius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 4,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 240, 237, 237),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text("Cashback"),
                                    SizedBox(width: 4),
                                    Icon(Icons.help_outline,size: 16),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SvgPicture.asset(
                                      "asset/coin.svg",
                                      height: 22,
                                    ),
                                    SizedBox(width: 2),
                                    Text(
                                      "₦ 4.00",
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 4),
                                    Icon(Icons.arrow_forward_ios, size: 16),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(width: 40),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text("Voucher"),
                                    SizedBox(width: 4),
                                    Container(
                                      padding: EdgeInsets.fromLTRB(3,0,3,0),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(36),
                                        gradient: mgrad
                                      ),
                                      child: Text(
                                        "₦250",
                                        style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Badge(
                                      backgroundColor: Colors.red,
                                      child: SvgPicture.asset(
                                        "asset/wallet.svg",
                                        height: 22,
                                      ),
                                    ),
                                    SizedBox(width: 2),
                                    Text(
                                      "1",
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 4),
                                    Icon(Icons.arrow_forward_ios, size: 16),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  // SizedBox(height: 12,),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.white,
                          ),
                          child: Reicon( tittle: "Friday Bonus", iconName: "asset/holdcash.svg") 
                        ),
                        SizedBox(width: 8,),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.white,
                          ),
                          child: Reicon(tittle: "Refer Freinds", iconName: "asset/kiss.svg", bgcolor: const Color.fromARGB(255, 255, 253, 220)) 
                        ),
                        SizedBox(width: 8,),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.white,
                          ),
                          child: Reicon(tittle: "Spin & Win", iconName: "asset/spin.svg", bgcolor: const Color.fromARGB(255, 186, 208, 226)) 
                        ),
                        SizedBox(width: 8,),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.white,
                          ),
                          child: Reicon( tittle: "Play4aChild", iconName: "asset/smilingface.svg", bgcolor: const Color.fromARGB(255, 255, 253, 220)) 
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16,),
                  Container(
                    padding: EdgeInsets.only(left: 6),
                    child: Row(
                      children: [
                        Text("Hot Vouchers", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                        SizedBox(width: 4,),
                        Container(
                          padding: EdgeInsets.only(left: 2,right: 2),
                          decoration: BoxDecoration(
                            color:  Color.fromARGB(255, 88, 204, 140)
                          ),
                          child: Text("|₦",style: TextStyle(fontSize: 12),),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 16,),
                  Container(
                    width: double.maxFinite,
                    padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text("Betting", style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold),),
                                Divider(color: Colors.green,  )
                              ],
                            )
                          ],
                        ),
                        Container(
                          width: 120,
                          padding: EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: const Color.fromARGB(255, 228, 255, 242)
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text("₦250", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.greenAccent),),
                              Text("Africa365 ₦250 off",textAlign: TextAlign.center,maxLines: 2,style: TextStyle(fontSize: 12,fontWeight: FontWeight.bold),)
                            ],
                          ),
                        ),
                        Container(padding: EdgeInsets.only(left: 10), width: 110, child: Brokenlines()),
                         Container(
                          width: 120,
                          padding: EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: const Color.fromARGB(255, 228, 255, 242)
                          ),
                          child: Column(
                            children: [
                              Text("₦1,000 available", style: TextStyle(fontSize: 11),),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 6,vertical: 2),
                                decoration: BoxDecoration(
        gradient: LinearGradient(colors: [const Color.fromARGB(255, 113, 243, 226), const Color.fromARGB(255, 88, 204, 140)]),
        borderRadius: BorderRadius.circular(30),
                ),
                                // decoration: BoxDecoration(
                                //   color: Colors.greenAccent,
                                //   borderRadius: BorderRadius.circular(30)
                                // ),
                                child: Text("Use",style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 16,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("View My Voucher",style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),),
                            Icon(Icons.arrow_forward_ios, size: 16,)
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 12,),
                  Text("Daily Bonus"),
                  SizedBox(height: 12,),
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      children: [
                        Rewardscard(title: "Glo Airtime ", subtitle: "Buy Airtime and get up ", moretitle: " +Up to 6%", percent: "6%", cashback: " Cashback"),
                        SizedBox(height: 12,),
                        Rewardscard(title: "9 Mobile Airtime ", subtitle: "Buy Airtime and get up ", moretitle: " +Up to 5%", percent: "5%", cashback: " Cashback"),
                        SizedBox(height: 12,),
                        Rewardscard(title: "MTN/Airtel Airtime ", subtitle: "Buy Airtime and get up ", moretitle: " +Up to 3.5%", percent: "3.5%", cashback: " Cashback"),
                        SizedBox(height: 12,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("View All"),
                            Icon(Icons.keyboard_arrow_down,size: 16,)
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
