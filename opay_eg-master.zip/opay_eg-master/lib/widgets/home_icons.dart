import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class HomeIcons extends StatelessWidget {
  final String iconName;
  final bool isCircle;
  final String tittle;
  final Color? bgcolor;
  final Color? iccolor;
  final double? fontChange;
  const HomeIcons({
    super.key,
    required this.isCircle,
    required this.tittle,
    required this.iconName,
    this.bgcolor,
    this.iccolor,
    this.fontChange,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          isCircle
              ? Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: bgcolor ?? const Color.fromARGB(255, 210, 240, 225),
                ),
                child: Center(
                  child: SvgPicture.asset(
                    iconName,
                    color: iccolor ?? const Color.fromARGB(255, 4, 177, 93),
                    width: 24,
                    height: 24,
                  ),
                ),
              )
              : Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: bgcolor ?? const Color.fromARGB(255, 210, 240, 225),
                ),
                child: Center(
                  child: SvgPicture.asset(
                    iconName,
                    color: iccolor ?? const Color.fromARGB(255, 4, 177, 93),
                    width: 24,
                    height: 24,
                  ),
                ),
              ),
          SizedBox(height: 8),
          Text(
            tittle,
            maxLines: 2,
            style:
                isCircle
                    ? TextStyle(fontSize: fontChange ?? 12)
                    : TextStyle(fontSize: fontChange ?? 14),
          ),
        ],
      ),
    );
  }
}

class Reicon extends StatelessWidget {
  final String iconName;
  final String tittle;
  final Color? bgcolor;
  const Reicon({
    super.key,
    required this.tittle,
    required this.iconName,
    this.bgcolor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: bgcolor ?? const Color.fromARGB(255, 210, 240, 225),
            ),
            child: Center(
              child: SvgPicture.asset(
                iconName,
                width: 24,
                height: 24,
                theme: SvgTheme(currentColor: Colors.transparent),
              ),
            ),
          ),
          SizedBox(height: 8),
          Text(tittle, style: TextStyle(fontSize: 9)),
        ],
      ),
    );
  }
}
