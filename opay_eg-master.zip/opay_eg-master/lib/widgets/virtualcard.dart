import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:opay_eg/widgets/cardlist.dart';

class VirtualCard extends StatefulWidget {
  const VirtualCard({super.key});

  @override
  State<VirtualCard> createState() => _VirtualCardState();
}

class _VirtualCardState extends State<VirtualCard> {
  @override
  Widget build(BuildContext context) {
    bool? checkboxval = false;
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 6),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 120, 211, 161),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SvgPicture.asset(
                              "asset/circledcircle.svg",
                              color: Colors.white,
                              width: 24,
                              height: 24,
                            ),
                            Text(
                              "Pay",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 100),
                        Row(
                          children: [
                            Text(
                              "Virtual Card",
                              style: TextStyle(color: Colors.white),
                            ),
                            Spacer(),
                            SvgPicture.asset(
                              "asset/verve-seeklogo.svg",
                              height: 24,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12),
                  Cardlist(
                    svg: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 2,
                      ),
                      child: SvgPicture.asset(
                        "asset/thunder.svg",
                        color: const Color.fromARGB(255, 4, 177, 93),
                        width: 22,
                        height: 22,
                      ),
                    ),

                    title: "Instant Access",
                    subtitle: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: "Apply and activate ",
                            style: TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                          TextSpan(
                            text: "Instantly",
                            style: TextStyle(
                              color: Color.fromARGB(255, 54, 153, 57),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 12),
                  Cardlist(
                    svg: Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 5,
                        horizontal: 2,
                      ),
                      child: SvgPicture.asset(
                        "asset/nigeria.svg",
                        color: const Color.fromARGB(255, 4, 177, 93),
                        width: 10,
                        height: 16,
                      ),
                    ),
                    title: "Rep Your State Of Origin",
                    subtitle: Container(
                      width: 220,
                      child: Text(
                        "Get a virtual Opay card unique to your state of origin",
                        maxLines: 2,
                        style: TextStyle(
                          fontSize: 11,
                          color: Color.fromARGB(255, 4, 177, 93),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 12),
                  Cardlist(
                    svg: SvgPicture.asset(
                      "asset/globe.svg",
                      color: const Color.fromARGB(255, 4, 177, 93),
                      width: 24,
                      height: 24,
                    ),
                    title: "Online Merchant Acceptance",
                    subtitle: Container(
                      width: 220,
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: "Accepted by ",
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey,
                              ),
                            ),
                            TextSpan(
                              text: "40,000+ ",
                              style: TextStyle(
                                color: Color.fromARGB(255, 54, 153, 57),
                              ),
                            ),
                            TextSpan(
                              text:
                                  "online merchants including JUMIA, KONGA, NETFLIX, UBER Wallet Funding and others",
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 12),
                  Cardlist(
                    svg: SvgPicture.asset(
                      "asset/shieldcheck.svg",
                      color: const Color.fromARGB(255, 4, 177, 93),
                      width: 24,
                      height: 24,
                    ),
                    title: "Security",
                    subtitle: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: "CBN",
                            style: TextStyle(
                              color: Color.fromARGB(255, 54, 153, 57),
                            ),
                          ),
                          TextSpan(
                            text: " licensed, ",
                            style: TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                          TextSpan(
                            text: "NDIC",
                            style: TextStyle(
                              color: Color.fromARGB(255, 54, 153, 57),
                            ),
                          ),
                          TextSpan(
                            text: " Insured",
                            style: TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Checkbox(
                  side: BorderSide(color: Color.fromARGB(255, 120, 211, 161)),
                  // fillColor: WidgetStatePropertyAll(Color.fromARGB(255, 120, 211, 161)),
                  value: checkboxval,
                  onChanged: (value) {
                    setState(() {
                      checkboxval = value;
                    });
                  },
                  checkColor: Color.fromARGB(255, 120, 211, 161),
                ),
                SizedBox(width: 4),
                Container(
                  width: 220,
                  child: Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(text: "Click the button below to accept "),
                        TextSpan(
                          text: "Terms & Conditions",
                          style: TextStyle(
                            color: Color.fromARGB(255, 4, 177, 93),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 120, 211, 161),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Center(
                child: Text(
                  "Get It Now",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
