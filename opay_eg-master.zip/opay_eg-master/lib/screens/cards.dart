import 'package:flutter/material.dart';
import 'package:opay_eg/widgets/physicalcard.dart';
import 'package:opay_eg/widgets/virtualcard.dart';

class Cards extends StatefulWidget {
  const Cards({super.key});

  @override
  State<Cards> createState() => _CardsState();
}

class _CardsState extends State<Cards> with SingleTickerProviderStateMixin {
  TabController? tabController;
  PageController controller = PageController();
  List<Widget> pages = [VirtualCard(), Physicalcard()];
  int firstPage = 0;
  void switchPage(int page) {
    setState(() {
      firstPage = page;
    });
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    tabController?.index = 0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 241, 240, 240),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 241, 240, 240),
        title: Text(
          "Cards",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        actions: [
          Text("Q&A", style: TextStyle(color: Colors.green, fontSize: 16)),
        ],
        actionsPadding: EdgeInsets.only(right: 16),
      ),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Virtual Card",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
              ),
              SizedBox(width: 10),
              Text(
                "Physical Card",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          TabPageSelector(
            controller: tabController,
            color: const Color.fromARGB(255, 211, 211, 211),
            selectedColor: const Color.fromARGB(255, 99, 98, 98),
          ),
          Flexible(
            child: PageView(
              controller: controller,
              onPageChanged: switchPage,
              scrollDirection: Axis.horizontal,
              children: pages,
            ),
          ),
        ],
      ),
    );
  }
}
