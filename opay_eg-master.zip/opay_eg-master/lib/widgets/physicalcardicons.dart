import 'package:flutter/material.dart';

class Physicalcardicons extends StatelessWidget {
  final Widget iconName;
  final String tittle;
  const Physicalcardicons({
    super.key,
    required this.tittle,
    required this.iconName,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        iconName,
    
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 98,
              child: Text(
                tittle,
                maxLines: 2,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
